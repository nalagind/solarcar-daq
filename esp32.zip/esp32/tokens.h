#ifndef TOKENS_H
#define TOKENS_H

// WiFi AP SSID
#define WIFI_SSID "BELL878"
// WiFi password
#define WIFI_PASSWORD "167DA273"
// InfluxDB v2 server or cloud API token (Use: InfluxDB UI -> Data -> API Tokens -> <select token>)
#define INFLUXDB_TOKEN "Lii_RHwzRindsBHKbEiYSAq2VyB8tEikMKPHg1jH4t9zWUsOILG9Qou499bCpy2TtfYl6uC4ctzCcVdTx1Z9xw=="
// #define INFLUXDB_TOKEN "Bs3FNFYit_4WxxjIo9_enUoxZs1FxdVc5INeML7p7oLul0S_Lziw-YBc-oMxhQFNRlZ-wJpt0Qravg6smEunXQ=="
#define INFLUXDB_URL "http://192.168.2.211:8086"

#endif